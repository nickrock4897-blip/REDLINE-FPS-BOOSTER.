package com.redline.fpsbooster;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 6102;
    private static final String PREFS = "redline_settings";
    private static final String KEY_HUD = "hud_enabled";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<GameOption> games = new ArrayList<>();
    private Spinner gameSpinner;
    private TextView logView;
    private TextView statusView;
    private TextView countdownView;
    private TextView hudStateView;
    private Button boostButton;
    private Button launchButton;
    private Button hudButton;
    private GameOption selectedGame;
    private boolean lowGraphicsSelected = false;
    private boolean pendingHudPermission = false;
    private int logStep = 0;

    private final int bg = Color.rgb(11, 11, 16);
    private final int panel = Color.rgb(25, 25, 34);
    private final int panel2 = Color.rgb(34, 34, 45);
    private final int red = Color.rgb(255, 57, 72);
    private final int white = Color.rgb(246, 246, 250);
    private final int muted = Color.rgb(169, 170, 185);
    private final int green = Color.rgb(73, 219, 145);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
        buildGames();
        buildUi();
        addLog("REDLINE FPS BOOSTER 1.0 gestartet.");
        addLog("Hinweis: Android erlaubt keine allgemeine CPU-/GPU-Übertaktung durch normale Apps.");
        updateHudStatus();
    }

    private void buildGames() {
        games.add(new GameOption("Roblox", "com.roblox.client"));
        games.add(new GameOption("Minecraft", "com.mojang.minecraftpe"));
        games.add(new GameOption("Brawl Stars", "com.supercell.brawlstars"));
        games.add(new GameOption("Stumble Guys", "com.kitkagames.fallbuddies"));
        games.add(new GameOption("Call of Duty: Mobile", "com.activision.callofduty.shooter"));
        games.add(new GameOption("PUBG Mobile", "com.tencent.ig"));
        games.add(new GameOption("Mobile Legends", "com.mobile.legends"));
        selectedGame = games.get(0);
    }

    private void buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        scroller.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("R", 25, red, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(round(red, 14));
        mark.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(52), dp(52));
        header.addView(mark, markLp);
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, 0, 0);
        titleCol.addView(text("REDLINE", 24, white, true));
        titleCol.addView(text("FPS BOOSTER  •  ANDROID", 11, muted, true));
        header.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);
        root.addView(space(16));

        LinearLayout hero = card();
        TextView heroTitle = text("GAME PERFORMANCE", 12, muted, true);
        hero.addView(heroTitle);
        TextView tagline = text("Mehr Kontrolle. Keine Fake-FPS.", 20, white, true);
        tagline.setPadding(0, dp(7), 0, dp(6));
        hero.addView(tagline);
        hero.addView(text("REDLINE prüft echte Gerätedaten, zeigt mögliche Engpässe und öffnet die passenden Android-Einstellungen. Versteckte Systemrechte werden nicht vorgetäuscht.", 13, muted, false));
        root.addView(hero);
        root.addView(space(14));

        LinearLayout gameCard = card();
        gameCard.addView(sectionTitle("01  SPIEL AUSWÄHLEN"));
        gameSpinner = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (GameOption game : games) {
            labels.add(game.name + (isInstalled(game.packageName) ? "  • installiert" : "  • nicht installiert"));
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gameSpinner.setAdapter(adapter);
        gameSpinner.setSelection(0);
        gameSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectedGame = games.get(position);
                if (statusView != null) {
                    statusView.setText(isInstalled(selectedGame.packageName)
                            ? selectedGame.name + " bereit zum Prüfen"
                            : selectedGame.name + " ist auf diesem Gerät nicht installiert");
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        gameCard.addView(gameSpinner);
        statusView = text("Roblox bereit zum Prüfen", 12, muted, false);
        statusView.setPadding(0, dp(8), 0, 0);
        gameCard.addView(statusView);
        root.addView(gameCard);
        root.addView(space(14));

        LinearLayout controls = card();
        controls.addView(sectionTitle("02  BOOST-PROFIL"));
        TextView profileText = text("Sicherer Check-up", 18, white, true);
        profileText.setPadding(0, dp(7), 0, dp(3));
        controls.addView(profileText);
        controls.addView(text("Speicher, Energiesparmodus, Temperatur, Display-Hz und HUD-Berechtigung werden geprüft. REDLINE beendet keine fremden Apps und ändert keine geschützten Android-Einstellungen automatisch.", 13, muted, false));
        controls.addView(space(12));
        boostButton = button("⚡  BOOST STARTEN", red, white);
        controls.addView(boostButton, matchWrap());
        boostButton.setOnClickListener(v -> showLowGraphicsQuestion());
        countdownView = text("", 26, red, true);
        countdownView.setGravity(Gravity.CENTER);
        countdownView.setPadding(0, dp(8), 0, 0);
        controls.addView(countdownView);
        launchButton = button("▶  SPIEL STARTEN", panel2, white);
        launchButton.setEnabled(false);
        launchButton.setAlpha(0.45f);
        controls.addView(launchButton, matchWrap());
        launchButton.setOnClickListener(v -> startGameCountdown());
        root.addView(controls);
        root.addView(space(14));

        LinearLayout hudCard = card();
        hudCard.addView(sectionTitle("03  FLOATING HUD"));
        hudStateView = text("Status wird geprüft …", 13, muted, false);
        hudStateView.setPadding(0, dp(8), 0, dp(8));
        hudCard.addView(hudStateView);
        hudButton = button("FLOATING HUD EINSCHALTEN", panel2, white);
        hudCard.addView(hudButton, matchWrap());
        hudButton.setOnClickListener(v -> toggleHud());
        Button displaySettings = button("DISPLAY- / HZ-EINSTELLUNGEN ÖFFNEN", panel2, white);
        LinearLayout.LayoutParams dslp = matchWrap();
        dslp.topMargin = dp(8);
        hudCard.addView(displaySettings, dslp);
        displaySettings.setOnClickListener(v -> openDisplaySettings());
        root.addView(hudCard);
        root.addView(space(14));

        LinearLayout logCard = card();
        LinearLayout logHeader = new LinearLayout(this);
        logHeader.setGravity(Gravity.CENTER_VERTICAL);
        logHeader.addView(sectionTitle("04  OPTIMIERUNGSPROTOKOLL"), new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = button("LEEREN", panel2, muted);
        clear.setTextSize(10);
        logHeader.addView(clear);
        logCard.addView(logHeader);
        clear.setOnClickListener(v -> logView.setText(""));
        logView = text("Warte auf Start …", 12, green, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setPadding(0, dp(12), 0, 0);
        logCard.addView(logView);
        root.addView(logCard);
        root.addView(space(14));
        root.addView(text("TRANSPARENZ: Android kann echten FPS-Wert eines anderen Spiels auf normalen Geräten nicht allgemein bereitstellen. Das HUD zeigt daher die Bildwiederholrate des Displays in Hz und kennzeichnet die Spiel-FPS als nicht verfügbar, statt Werte zu erfinden.", 11, muted, false));

        setContentView(scroller);
    }

    private void showLowGraphicsQuestion() {
        new AlertDialog.Builder(this)
                .setTitle("Low Graphics?")
                .setMessage("Möchtest du vor dem Start niedrige Grafikeinstellungen verwenden? REDLINE kann die Roblox-Grafik nicht automatisch verändern. Bei Ja zeigt es dir die Schritte.")
                .setPositiveButton("Ja, Low Graphics", (dialog, which) -> {
                    lowGraphicsSelected = true;
                    new AlertDialog.Builder(this)
                            .setTitle("Low Graphics einstellen")
                            .setMessage("In Roblox: Menü öffnen → Settings/Einstellungen → Graphics Mode auf Manual stellen → Graphics Quality nach links auf niedrig ziehen. Das muss im Spiel selbst gemacht werden.")
                            .setPositiveButton("Weiter zum Boost", (d, w) -> startBoostProcess(true))
                            .setNegativeButton("Später", (d, w) -> startBoostProcess(true))
                            .show();
                })
                .setNegativeButton("Nein", (dialog, which) -> {
                    lowGraphicsSelected = false;
                    startBoostProcess(false);
                })
                .setNeutralButton("Abbrechen", null)
                .show();
    }

    private void startBoostProcess(boolean lowGraphics) {
        lowGraphicsSelected = lowGraphics;
        logView.setText("");
        logStep = 0;
        boostButton.setEnabled(false);
        boostButton.setAlpha(0.55f);
        launchButton.setEnabled(false);
        launchButton.setAlpha(0.45f);
        countdownView.setText("PRÜFE …");
        List<Runnable> tasks = new ArrayList<>();
        tasks.add(() -> addLog("START: Sicherer Performance-Check für " + selectedGame.name + "."));
        tasks.add(() -> {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
            String available = formatBytes(mi.availMem);
            String total = mi.totalMem > 0 ? formatBytes(mi.totalMem) : "unbekannt";
            addLog("OK  Gerätespeicher gelesen: " + available + " frei / " + total + " gesamt.");
        });
        tasks.add(() -> {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            boolean saver = pm != null && pm.isPowerSaveMode();
            addLog((saver ? "HINWEIS" : "OK") + " Energiesparmodus geprüft: " + (saver ? "AKTIV – kann Leistung begrenzen." : "nicht aktiv") + ". Keine Änderung ohne Nutzeraktion.");
        });
        tasks.add(() -> {
            String thermal = getThermalDescription();
            addLog("OK  Temperatur-/Thermalstatus geprüft: " + thermal + ".");
        });
        tasks.add(() -> {
            float hz = currentRefreshRate();
            addLog("OK  Display-Wiederholrate gelesen: " + String.format(Locale.getDefault(), "%.0f Hz", hz) + ". Das ist nicht automatisch die Spiel-FPS.");
        });
        tasks.add(() -> addLog(Settings.canDrawOverlays(this)
                ? "OK  Floating-HUD-Berechtigung ist erteilt."
                : "HINWEIS  HUD-Berechtigung fehlt; zum Einblenden muss sie in Android erlaubt werden."));
        tasks.add(() -> addLog(lowGraphics
                ? "AUSWAHL  Low Graphics: JA. Die Spielgrafik muss im Spiel manuell umgestellt werden."
                : "AUSWAHL  Low Graphics: NEIN. Grafikeinstellungen bleiben unverändert."));
        tasks.add(() -> addLog("SICHERHEIT  Keine fremden Apps zwangsweise beendet; Android verwaltet Hintergrundprozesse."));
        tasks.add(() -> {
            addLog("FERTIG  Alle verfügbaren Prüfungen abgeschlossen. Keine geschützten Systemwerte automatisch verändert.");
            countdownView.setText("BOOST-CHECK FERTIG");
            boostButton.setEnabled(true);
            boostButton.setAlpha(1f);
            launchButton.setEnabled(true);
            launchButton.setAlpha(1f);
            statusView.setText(selectedGame.name + " • bereit zum Starten");
        });
        runNextTask(tasks, 0);
    }

    private void runNextTask(List<Runnable> tasks, int index) {
        if (index >= tasks.size()) return;
        handler.postDelayed(() -> {
            tasks.get(index).run();
            runNextTask(tasks, index + 1);
        }, index == 0 ? 100 : 420);
    }

    private void startGameCountdown() {
        if (selectedGame == null || !isInstalled(selectedGame.packageName)) {
            Toast.makeText(this, selectedGame == null ? "Bitte ein Spiel auswählen." : selectedGame.name + " ist nicht installiert.", Toast.LENGTH_LONG).show();
            return;
        }
        launchButton.setEnabled(false);
        launchButton.setAlpha(0.55f);
        final int[] n = {3};
        countdownView.setText("START IN 3");
        handler.post(new Runnable() {
            @Override public void run() {
                if (n[0] > 0) {
                    countdownView.setText("START IN " + n[0]);
                    n[0]--;
                    handler.postDelayed(this, 1000);
                } else {
                    countdownView.setText("LOS!");
                    launchSelectedGame();
                    launchButton.setEnabled(true);
                    launchButton.setAlpha(1f);
                }
            }
        });
    }

    private void launchSelectedGame() {
        try {
            if (getHudWanted() && Settings.canDrawOverlays(this)) startHudService();
            Intent launch = getPackageManager().getLaunchIntentForPackage(selectedGame.packageName);
            if (launch == null) {
                addLog("FEHLER  Kein Startbildschirm für " + selectedGame.name + " gefunden.");
                Toast.makeText(this, "Spiel konnte nicht gestartet werden.", Toast.LENGTH_LONG).show();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            addLog("START  Öffne " + selectedGame.name + ".");
            startActivity(launch);
        } catch (Exception ex) {
            addLog("FEHLER  Spiel konnte nicht geöffnet werden: " + ex.getClass().getSimpleName());
            Toast.makeText(this, "Spiel konnte nicht geöffnet werden.", Toast.LENGTH_LONG).show();
        }
    }

    private void toggleHud() {
        if (getHudWanted()) {
            stopService(new Intent(this, HudOverlayService.class));
            setHudWanted(false);
            updateHudStatus();
            addLog("HUD  Floating HUD ausgeschaltet.");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            pendingHudPermission = true;
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            } catch (Exception e) {
                Toast.makeText(this, "Öffne Android-Einstellungen und erlaube 'Über anderen Apps anzeigen'.", Toast.LENGTH_LONG).show();
            }
        } else {
            setHudWanted(true);
            startHudService();
            updateHudStatus();
        }
    }

    private void startHudService() {
        if (!Settings.canDrawOverlays(this)) {
            addLog("HUD  Kann nicht starten: Android-Overlay-Berechtigung fehlt.");
            return;
        }
        try {
            Intent intent = new Intent(this, HudOverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
            setHudWanted(true);
            addLog("HUD  Movable Overlay gestartet; ziehe das HUD an seinem Text an die gewünschte Stelle.");
        } catch (Exception e) {
            setHudWanted(false);
            addLog("HUD  Start fehlgeschlagen: " + e.getClass().getSimpleName());
            Toast.makeText(this, "Android hat das Floating HUD nicht gestartet.", Toast.LENGTH_LONG).show();
        }
        updateHudStatus();
    }

    private void openDisplaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Einstellungen konnten nicht geöffnet werden.", Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && pendingHudPermission) {
            pendingHudPermission = false;
            if (Settings.canDrawOverlays(this)) {
                setHudWanted(true);
                startHudService();
                Toast.makeText(this, "Floating HUD eingeschaltet.", Toast.LENGTH_SHORT).show();
            } else {
                setHudWanted(false);
                Toast.makeText(this, "Ohne Overlay-Berechtigung kann das HUD nicht über Roblox erscheinen.", Toast.LENGTH_LONG).show();
            }
            updateHudStatus();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (hudStateView != null) updateHudStatus();
    }

    private void updateHudStatus() {
        boolean permission = Settings.canDrawOverlays(this);
        boolean enabled = getHudWanted();
        if (hudStateView != null) {
            hudStateView.setText(enabled && permission
                    ? "HUD ist eingeschaltet. FPS des Spiels sind auf normalem Android nicht allgemein abrufbar; Display-Hz werden angezeigt."
                    : permission
                        ? "Berechtigung vorhanden. HUD ist aktuell ausgeschaltet."
                        : "Für ein HUD über Roblox ist die Android-Berechtigung 'Über anderen Apps anzeigen' erforderlich.");
        }
        if (hudButton != null) hudButton.setText(enabled ? "FLOATING HUD AUSSCHALTEN" : "FLOATING HUD EINSCHALTEN");
    }

    private String getThermalDescription() {
        if (Build.VERSION.SDK_INT < 29) return "nicht von dieser Android-Version angeboten";
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null) return "nicht verfügbar";
        try {
            switch (pm.getCurrentThermalStatus()) {
                case PowerManager.THERMAL_STATUS_NONE: return "normal";
                case PowerManager.THERMAL_STATUS_LIGHT: return "leicht erhöht";
                case PowerManager.THERMAL_STATUS_MODERATE: return "moderat";
                case PowerManager.THERMAL_STATUS_SEVERE: return "hoch – Gerät kann drosseln";
                case PowerManager.THERMAL_STATUS_CRITICAL: return "kritisch – Pause empfohlen";
                case PowerManager.THERMAL_STATUS_EMERGENCY: return "Notfall";
                case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Abschaltung droht";
                default: return "unbekannt";
            }
        } catch (Exception e) { return "nicht verfügbar"; }
    }

    private float currentRefreshRate() {
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null && wm.getDefaultDisplay() != null) return wm.getDefaultDisplay().getRefreshRate();
        } catch (Exception ignored) { }
        return 0f;
    }

    private boolean isInstalled(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0));
            else pm.getPackageInfo(packageName, 0);
            return true;
        } catch (Exception e) { return false; }
    }

    private String formatBytes(long value) {
        if (value <= 0) return "unbekannt";
        float gb = value / (1024f * 1024f * 1024f);
        if (gb >= 1) return String.format(Locale.getDefault(), "%.1f GB", gb);
        return String.format(Locale.getDefault(), "%.0f MB", value / (1024f * 1024f));
    }

    private void addLog(String text) {
        if (logView == null) return;
        String time = new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date());
        logView.append("[" + time + "] " + text + "\n\n");
    }

    private boolean getHudWanted() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_HUD, false);
    }
    private void setHudWanted(boolean value) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_HUD, value).apply();
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackground(round(panel, 18));
        return l;
    }
    private TextView sectionTitle(String s) { return text(s, 12, red, true); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(dp(2), 1.02f);
        return t;
    }
    private Button button(String label, int color, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackground(round(color, 14));
        if (Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
        return b;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private View space(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return v;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private static class GameOption {
        final String name;
        final String packageName;
        GameOption(String name, String packageName) { this.name = name; this.packageName = packageName; }
    }
}

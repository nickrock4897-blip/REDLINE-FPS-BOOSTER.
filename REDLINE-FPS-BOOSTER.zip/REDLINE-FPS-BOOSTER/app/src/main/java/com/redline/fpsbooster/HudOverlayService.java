package com.redline.fpsbooster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class HudOverlayService extends Service {
    private static final String CHANNEL_ID = "redline_hud_channel";
    private static final int NOTIFICATION_ID = 7102;
    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams layoutParams;
    private TextView statsText;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable updateRunnable = new Runnable() {
        @Override public void run() {
            if (statsText != null) {
                float hz = currentDisplayHz();
                String hzText = hz > 0 ? String.format(Locale.getDefault(), "%.0f Hz", hz) : "n/v";
                statsText.setText("REDLINE  •  FPS --\nDISPLAY  " + hzText + "\nGame-FPS: nicht verfügbar");
            }
            handler.postDelayed(this, 1500);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        if (Settings.canDrawOverlays(this)) createOverlay();
        else stopSelf();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (overlayView == null && Settings.canDrawOverlays(this)) createOverlay();
        return START_NOT_STICKY;
    }

    private void createOverlay() {
        if (overlayView != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) { stopSelf(); return; }

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        container.setPadding(dp(12), dp(8), dp(8), dp(8));
        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(21, 21, 29), Color.rgb(48, 20, 28)});
        background.setCornerRadius(dp(16));
        background.setStroke(dp(1), Color.rgb(255, 57, 72));
        container.setBackground(background);

        statsText = new TextView(this);
        statsText.setTextColor(Color.WHITE);
        statsText.setTextSize(11);
        statsText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statsText.setLineSpacing(dp(1), 1.0f);
        statsText.setText("REDLINE  •  FPS --\nDISPLAY  -- Hz\nGame-FPS: nicht verfügbar");
        statsText.setPadding(0, 0, dp(12), 0);
        container.addView(statsText, new LinearLayout.LayoutParams(-2, -2, 1));

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextSize(22);
        close.setTextColor(Color.rgb(255, 113, 123));
        close.setGravity(Gravity.CENTER);
        close.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        close.setContentDescription("Floating HUD schließen");
        container.addView(close, new LinearLayout.LayoutParams(dp(32), dp(36)));
        close.setOnClickListener(v -> {
            getSharedPreferences("redline_settings", MODE_PRIVATE).edit().putBoolean("hud_enabled", false).apply();
            stopSelf();
        });

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(10);
        layoutParams.y = dp(100);

        statsText.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = layoutParams.x;
                        startY = layoutParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > dp(3) || Math.abs(dy) > dp(3)) moved = true;
                        layoutParams.x = Math.max(0, startX + dx);
                        layoutParams.y = Math.max(0, startY + dy);
                        try { windowManager.updateViewLayout(overlayView, layoutParams); } catch (Exception ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        return true;
                    default: return false;
                }
            }
        });

        overlayView = container;
        try {
            windowManager.addView(overlayView, layoutParams);
            handler.post(updateRunnable);
        } catch (Exception e) {
            overlayView = null;
            stopSelf();
        }
    }

    private float currentDisplayHz() {
        try {
            if (windowManager != null && windowManager.getDefaultDisplay() != null) {
                return windowManager.getDefaultDisplay().getRefreshRate();
            }
        } catch (Exception ignored) { }
        return 0f;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "REDLINE Floating HUD", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Zeigt das von dir eingeschaltete Performance-HUD an.");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setContentTitle("REDLINE Floating HUD aktiv")
                    .setContentText("Ziehe das HUD am Text an die gewünschte Position.")
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("REDLINE Floating HUD aktiv")
                .setContentText("Performance HUD aktiv.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(updateRunnable);
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
        }
        overlayView = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}

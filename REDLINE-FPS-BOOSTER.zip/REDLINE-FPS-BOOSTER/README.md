# REDLINE FPS BOOSTER (Android project)

A native Java Android app prototype with a visible optimization log, supported-game selection, an optional Low Graphics walkthrough, a 3-2-1 launch countdown, and a movable floating HUD overlay.

## Important limits (not bugs to hide)

- A normal, non-root Android app cannot overclock the CPU/GPU, edit protected system settings, or force-close other apps at will. REDLINE does not pretend to do these things.
- The boost process reads available RAM, checks Android's battery-saver and thermal status when supported, reads the display refresh rate, and checks overlay permission. It reports these actions in the log.
- The HUD reports display refresh rate in **Hz**. It does not claim this is the game's FPS. Standard Android APIs do not offer a universal way for an ordinary app to read another app's live FPS.
- The Low Graphics choice explains how to change in-game Roblox graphics manually. It does not silently modify Roblox.
- The display settings button opens Android display settings; the user may choose a higher refresh-rate mode if the device exposes one.
- The HUD needs the user-granted **Display over other apps** permission and uses a foreground-service notification while active.

## Build in GitHub Actions (no computer required, if using GitHub in a mobile browser)

### If you upload the extracted project contents

1. Download and extract `REDLINE-FPS-BOOSTER.zip` on your device.
2. Create a repository on GitHub. For a private project, choose **Private**.
3. Upload the extracted *contents* of the `REDLINE-FPS-BOOSTER` folder to the repository root (not just the ZIP file). Keep the `.github/workflows/android.yml` file and all subfolders.
4. Open **Actions** in the repository and allow workflows if GitHub asks.
5. Open the workflow **Build REDLINE APK**. Choose **Run workflow** if it has not started automatically.
6. When it finishes successfully, open the run and download the artifact named `REDLINE-FPS-BOOSTER-debug-APK`.
7. Extract that artifact ZIP. It contains `app-debug.apk`. Open the APK on your Android device and approve installation from that source if Android asks.

On a phone, GitHub's website may require Chrome's **Desktop site** view to upload many files/folders. Do not upload passwords, signing keys, or personal data into the repository.

### If you only upload this project ZIP

A ZIP file is not automatically an active GitHub Actions workflow. Create `.github/workflows/build.yml` in the repository and paste the separate `REDLINE_MOBILE_CLOUD_BUILD_WORKFLOW.yml` file provided with this project. Then upload `REDLINE-FPS-BOOSTER.zip` to the repository root. The workflow unpacks the ZIP, builds it in GitHub's cloud, and publishes the APK as an artifact.

## Build locally with Android Studio

Open this folder as an Android Studio project, use JDK 17, install Android SDK Platform 35 and Build Tools 35.0.0, then run **Build > Build APK(s)** or `gradle :app:assembleDebug`. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Supported launcher targets

Roblox, Minecraft, Brawl Stars, Stumble Guys, Call of Duty: Mobile, PUBG Mobile, and Mobile Legends. Only games installed on the device will launch. Package availability can vary by region and store.
